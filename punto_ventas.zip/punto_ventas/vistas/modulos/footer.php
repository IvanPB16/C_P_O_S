<footer class="main-footer">
	
	<strong>Copyright &copy; 2018 <a href="https://www.facebook.com" target="_blank">CompuActual</a>.</strong>

	Todos los derechos reservados.
	
</footer>